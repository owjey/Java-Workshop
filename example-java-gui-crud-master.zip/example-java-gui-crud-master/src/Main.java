import pages.LoginPage;

import javax.swing.*;

//CARATIHAN, Odessa Jen C.
//BSIT 2-2 WORKSHOP ACTIVITY
//ADDED SIGN UP OPTION IN LOG IN PAGE

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(LoginPage::new);
    }
}